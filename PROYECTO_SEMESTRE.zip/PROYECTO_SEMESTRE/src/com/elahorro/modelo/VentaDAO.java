/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.elahorro.modelo;

import com.elahorro.conexion.Conexion;
import java.sql.*;
import java.util.List;

public class VentaDAO {

    public boolean registrarVentaCompleta(Venta venta, List<DetalleVenta> detalles) {
        Connection cn = null;
        PreparedStatement psVenta = null;
        PreparedStatement psDetalle = null;
        PreparedStatement psStock = null;
        PreparedStatement psPuntos = null; // 🚨 Declaramos el statement para puntos
        ResultSet rs = null;

        String sqlVenta = "INSERT INTO venta (fecha_hora, id_cliente, id_empleado, id_sucursal) VALUES (?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        String sqlStock = "UPDATE producto SET stock_actual = stock_actual - ? WHERE id_producto = ?";
        
        // 🚨 Consulta SQL para actualizar los puntos en PostgreSQL
        String sqlPuntos = "UPDATE cliente SET puntos_acumulados = puntos_acumulados + ? WHERE id_cliente = ?";

        try {
            cn = Conexion.conectar();
            // ACTIVAMOS LA TRANSACCIÓN
            cn.setAutoCommit(false);

            // 1. Insertar la cabecera de la venta con su fecha correspondiente
            psVenta = cn.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);

            // El primer signo de interrogación es la fecha y hora del sistema
            psVenta.setTimestamp(1, new java.sql.Timestamp(System.currentTimeMillis()));

            // El segundo es el cliente (manejando si es 0 u ocasional)
            if (venta.getIdCliente() == 0) {
                psVenta.setNull(2, Types.INTEGER);
            } else {
                psVenta.setInt(2, venta.getIdCliente());
            }

            // El tercero es el empleado y el cuarto la sucursal
            psVenta.setInt(3, venta.getIdEmpleado());
            psVenta.setInt(4, venta.getIdSucursal());

            psVenta.executeUpdate();

            // Obtenemos el ID de la venta que generó PostgreSQL
            rs = psVenta.getGeneratedKeys();
            int idVentaGenerado = 0;
            if (rs.next()) {
                idVentaGenerado = rs.getInt(1);
            }

            // 2. Preparar los statements para los detalles, stock y puntos
            psDetalle = cn.prepareStatement(sqlDetalle);
            psStock = cn.prepareStatement(sqlStock);
            psPuntos = cn.prepareStatement(sqlPuntos); // 🚨 Inicializamos el statement de puntos

            // Recorremos la lista del "carrito de compras" que viene de la interfaz
            double totalFactura = 0; // 🚨 Variable para calcular el total de la compra
            
            for (DetalleVenta det : detalles) {
                // Insertar renglón del detalle
                psDetalle.setInt(1, idVentaGenerado);
                psDetalle.setInt(2, det.getIdProducto());
                psDetalle.setInt(3, det.getCantidad());
                psDetalle.setDouble(4, det.getPrecioUnitario());
                psDetalle.addBatch(); 

                // Restar del stock actual del producto
                psStock.setInt(1, det.getCantidad());
                psStock.setInt(2, det.getIdProducto());
                psStock.addBatch();
                
                // Acumulamos el total de la factura
                totalFactura += (det.getCantidad() * det.getPrecioUnitario());
            }

            // Ejecutamos los lotes de detalles y stock
            psDetalle.executeBatch();
            psStock.executeBatch();

            // 3. 🚨 REGISTRO AUTOMÁTICO DE PUNTOS DE FIDELIDAD
            // Solo sumamos puntos si NO es cliente ocasional (ID diferente de 0)
            if (venta.getIdCliente() != 0) {
                // REGLA DEL NEGOCIO: 1 punto por cada $1.000 pesos de compra
                int puntosGanados = (int) (totalFactura / 1000); 

                if (puntosGanados > 0) {
                    psPuntos.setInt(1, puntosGanados);
                    psPuntos.setInt(2, venta.getIdCliente());
                    psPuntos.executeUpdate();
                    System.out.println("--- PUNTOS GUARDADOS EN BD: " + puntosGanados + " para el cliente ID: " + venta.getIdCliente());
                }
            }

            // 🔥 SI TODO SALIÓ BIEN, CORONAMOS LA TRANSACCIÓN
            cn.commit();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la transacción de venta: " + e.getMessage());
            
            // Ventana de alerta con el error exacto
            javax.swing.JOptionPane.showMessageDialog(null, "ERROR DE POSTGRESQL:\n" + e.getMessage(), "Detalle del Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            
            if (cn != null) {
                try {
                    cn.rollback();
                } catch (SQLException ex) {
                    System.out.println("Error al hacer rollback: " + ex.getMessage());
                }
            }
            return false;
        } finally {
            // Cerramos todos los recursos para evitar fugas de conexión
            try {
                if (rs != null) rs.close();
                if (psVenta != null) psVenta.close();
                if (psDetalle != null) psDetalle.close();
                if (psStock != null) psStock.close();
                if (psPuntos != null) psPuntos.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}