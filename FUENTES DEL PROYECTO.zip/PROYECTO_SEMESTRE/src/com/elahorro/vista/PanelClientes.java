/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.elahorro.vista;

import com.elahorro.modelo.Cliente;
import com.elahorro.modelo.ClienteDAO;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PanelClientes extends javax.swing.JPanel {


    private ClienteDAO clienteDAO = new ClienteDAO();
    private DefaultTableModel modeloTabla;
    private int idClienteSeleccionado = -1; 

    public PanelClientes() {
        initComponents();
        listarClientesEnTabla(); 
    }

  
    private void limpiarCampos() {
        txtDocumento.setText("");
        txtNombre.setText("");
        txtEmail.setText("");
        idClienteSeleccionado = -1;
    }


    private void listarClientesEnTabla() {
javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaClientes.getModel();
    modelo.setRowCount(0); 
 
    java.util.List<com.elahorro.modelo.Cliente> lista = clienteDAO.listarClientes();


    for (com.elahorro.modelo.Cliente c : lista) {
        Object[] fila = new Object[5];
        fila[0] = c.getIdCliente();
        fila[1] = c.getDocumento();
        fila[2] = c.getNombre();
        fila[3] = c.getEmail();
        fila[4] = c.getPuntosAcumulados();
        
       
        modelo.addRow(fila); 
    }
    }

  
                                           
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtDocumento = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClientes = new javax.swing.JTable();

        txtDocumento.addActionListener(this::txtDocumentoActionPerformed);

        jLabel1.setText("Documento");

        jLabel2.setText("Nombre");

        jLabel3.setText("Email");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        btnEditar.setText("Actualizar");
        btnEditar.addActionListener(this::btnEditarActionPerformed);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(this::btnEliminarActionPerformed);

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);

        tablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id Cliente", "Documento", "Nombre", "Email", "Puntos"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                true, true, true, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaClientes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtDocumento, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                                .addComponent(txtNombre)
                                .addComponent(txtEmail))
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(13, 13, 13)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(btnGuardar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminar)
                        .addGap(18, 18, 18)
                        .addComponent(btnLimpiar)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnEditar)
                    .addComponent(btnEliminar)
                    .addComponent(btnLimpiar))
                .addContainerGap(46, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
     if (txtDocumento.getText().trim().isEmpty() || txtNombre.getText().trim().isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "El documento y el nombre son obligatorios.");
        return;
    }

    com.elahorro.modelo.Cliente nuevoCliente = new com.elahorro.modelo.Cliente();
    nuevoCliente.setDocumento(txtDocumento.getText().trim());
    nuevoCliente.setNombre(txtNombre.getText().trim());
    nuevoCliente.setEmail(txtEmail.getText().trim());

    if (clienteDAO.registrarCliente(nuevoCliente)) {
        javax.swing.JOptionPane.showMessageDialog(this, "¡Cliente registrado con éxito en El Ahorro!");
        listarClientesEnTabla(); 
        limpiarCampos();         
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar. Verifica si el documento ya está registrado.");
    }
 
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaClientes.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, selecciona un cliente de la tabla para modificarlo.");
        return;
    }

 
    int id = (int) tablaClientes.getValueAt(filaSeleccionada, 0);
    
  
    com.elahorro.modelo.Cliente clienteActualizar = new com.elahorro.modelo.Cliente();
    clienteActualizar.setIdCliente(id);
    clienteActualizar.setDocumento(txtDocumento.getText().trim());
    clienteActualizar.setNombre(txtNombre.getText().trim());
    clienteActualizar.setEmail(txtEmail.getText().trim());

  
    if (clienteDAO.actualizarCliente(clienteActualizar)) {
        javax.swing.JOptionPane.showMessageDialog(this, "¡Datos del cliente actualizados correctamente!");
        listarClientesEnTabla(); // Refresca la tabla
        limpiarCampos();
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al actualizar los datos del cliente.");
    }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = tablaClientes.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, selecciona un cliente de la tabla para eliminarlo.");
        return;
    }


    int id = (int) tablaClientes.getValueAt(filaSeleccionada, 0);
    

    int confirmar = javax.swing.JOptionPane.showConfirmDialog(this, 
            "¿Seguro que deseas eliminar este cliente del sistema?", 
            "Confirmar Eliminación", 
            javax.swing.JOptionPane.YES_NO_OPTION, 
            javax.swing.JOptionPane.WARNING_MESSAGE);
    
    if (confirmar == javax.swing.JOptionPane.YES_OPTION) {
  
        if (clienteDAO.eliminarCliente(id)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Cliente eliminado con éxito.");
            listarClientesEnTabla(); // Refresca la tabla
            limpiarCampos();
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "No se pudo eliminar el cliente. (Podría tener ventas asociadas)");
        }
    }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
      limpiarCampos();
        
    }//GEN-LAST:event_btnLimpiarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}