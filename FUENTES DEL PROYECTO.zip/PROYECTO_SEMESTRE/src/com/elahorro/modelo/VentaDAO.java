/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.elahorro.modelo;

import com.elahorro.conexion.Conexion;
import java.sql.*;
import java.util.List;

public class VentaDAO {

    public boolean registrarVentaCompleta(Venta venta, List<DetalleVenta> detalles) {
        Connection cn = null;
        PreparedStatement psVenta = null;
        PreparedStatement psDetalle = null;
        PreparedStatement psStock = null;
        PreparedStatement psPuntos = null;
        ResultSet rs = null;

        String sqlVenta = "INSERT INTO venta (fecha_hora, id_cliente, id_empleado, id_sucursal) VALUES (?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        String sqlStock = "UPDATE producto SET stock_actual = stock_actual - ? WHERE id_producto = ?";
        
        String sqlPuntos = "UPDATE cliente SET puntos_acumulados = puntos_acumulados + ? WHERE id_cliente = ?";

        try {
            cn = Conexion.conectar();
            cn.setAutoCommit(false);

            psVenta = cn.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);

            psVenta.setTimestamp(1, new java.sql.Timestamp(System.currentTimeMillis()));

            if (venta.getIdCliente() == 0) {
                psVenta.setNull(2, Types.INTEGER);
            } else {
                psVenta.setInt(2, venta.getIdCliente());
            }
            
        psVenta.setInt(3, venta.getIdEmpleado());
            psVenta.setInt(4, venta.getIdSucursal());

            psVenta.executeUpdate();

            rs = psVenta.getGeneratedKeys();
            int idVentaGenerado = 0;
            if (rs.next()) {
                idVentaGenerado = rs.getInt(1);
            }
            
            psDetalle = cn.prepareStatement(sqlDetalle);
            psStock = cn.prepareStatement(sqlStock);
            psPuntos = cn.prepareStatement(sqlPuntos);


            double totalFactura = 0; 
            
            for (DetalleVenta det : detalles) {
      
                psDetalle.setInt(1, idVentaGenerado);
                psDetalle.setInt(2, det.getIdProducto());
                psDetalle.setInt(3, det.getCantidad());
                psDetalle.setDouble(4, det.getPrecioUnitario());
                psDetalle.addBatch(); 

        
                psStock.setInt(1, det.getCantidad());
                psStock.setInt(2, det.getIdProducto());
                psStock.addBatch();
                
        
                totalFactura += (det.getCantidad() * det.getPrecioUnitario());
            }


            psDetalle.executeBatch();
            psStock.executeBatch();

            
            if (venta.getIdCliente() != 0) {
   
                int puntosGanados = (int) (totalFactura / 1000); 

                if (puntosGanados > 0) {
                    psPuntos.setInt(1, puntosGanados);
                    psPuntos.setInt(2, venta.getIdCliente());
                    psPuntos.executeUpdate();
                    System.out.println("--- PUNTOS GUARDADOS EN BD: " + puntosGanados + " para el cliente ID: " + venta.getIdCliente());
                }
            }

      
            cn.commit();
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la transacción de venta: " + e.getMessage());
            

            javax.swing.JOptionPane.showMessageDialog(null, "ERROR DE POSTGRESQL:\n" + e.getMessage(), "Detalle del Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            
            if (cn != null) {
                try {
                    cn.rollback();
                } catch (SQLException ex) {
                    System.out.println("Error al hacer rollback: " + ex.getMessage());
                }
            }
            return false;
        } finally {

            try {
                if (rs != null) rs.close();
                if (psVenta != null) psVenta.close();
                if (psDetalle != null) psDetalle.close();
                if (psStock != null) psStock.close();
                if (psPuntos != null) psPuntos.close();
                if (cn != null) cn.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}